<?php

namespace App\Filament\Resources\JuriResource\Pages;

use App\Filament\Resources\JuriResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateJuri extends CreateRecord
{
    protected static string $resource = JuriResource::class;
}
